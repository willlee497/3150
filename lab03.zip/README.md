# Lab Week 3: Linked Lists

## Overview
//O: This lab extends the Node structure to include a copy constructor (for deep copying) and a destructor (for recursive deletion).  
//O: It also provides several linked list operations:  
//   - **build_linked_list**: Creates a linked list from a vector of integers.  
//   - **print_linked_list**: Outputs the list in a formatted string ("value -> value -> ... -> nullptr").  
//   - **delete_entire_linked_list**: Deletes the entire list and resets the head pointer to nullptr.  
//   - **get_linked_list_data_item_value**: Retrieves the data value at a specified index (0-indexed).  
//   - **delete_list_element**: Deletes a specific node by its index (0-indexed).  
//O: Unit tests are implemented using the [doctest](https://github.com/doctest/doctest) framework.

## File Structure
//FS: The repository contains the following files:
- **linked_list.h**: Contains the declarations for the Node structure and linked list functions.
- **linked_list.cpp**: Contains the definitions of the Node methods and linked list functions.
- **linked_list_test.cpp**: Contains unit tests for the linked list functions using the doctest framework.
- **doctest.h**: (Download this file using wget as described below; it is required for running the tests.)
- **README.md**: This file with instructions on how to compile and run the tests.

## How to Set Up
//S: Download the latest `doctest.h` file if you don't already have it:
//S: Open your terminal and run:
```bash
wget https://raw.githubusercontent.com/doctest/doctest/master/doctest/doctest.h
Make sure doctest.h is in the same directory as the test file or adjust the include path accordingly.

Compiling the Code
//C: Open your terminal and navigate to the lab folder:

cd CSE3150/Labs/lab03
//C: Compile the code using g++ with C++17 support:


g++ -std=c++17 -o linkedlist linked_list_test.cpp linked_list.cpp
Running the Tests
//R: Run the resulting executable:


./linkedlist
//R: The tests will run automatically using the doctest framework and display the results in the terminal.

Additional Information
//I: The linked list functions use 0-indexed numbering, so the first node is at index 0.
//I: The Node destructor recursively deletes subsequent nodes, so when deleting a single node (using delete_list_element), the node’s next pointer is set to nullptr to prevent accidental deletion of the rest of the list.
//I: The copy constructor of Node performs a deep copy, ensuring that when a node is copied, the entire list from that node is copied as well.

