#include "linked_list.h"

//CC: Copy Constructor that deep copies the current node and its successors.
Node::Node(const Node& other) {
    data = other.data;
    next = (other.next) ? new Node(*other.next) : nullptr;
}

//D: Destructor that recursively deletes the next node.
Node::~Node() {
    delete next;
}

//BL: Create a linked list from a vector of integers.
Node* build_linked_list(const std::vector<int>& values) {
    Node* head = nullptr;
    Node* tail = nullptr;
    for (int val : values) {
        Node* new_node = new Node(val);
        if (!head) {
            head = tail = new_node;
        } else {
            tail->next = new_node;
            tail = new_node;
        }
    }
    return head;
}

//PL: Print the linked list in the format "value -> value -> ... -> nullptr".
void print_linked_list(Node* head) {
    Node* current = head;
    while (current) {
        std::cout << current->data << " -> ";
        current = current->next;
    }
    std::cout << "nullptr" << std::endl;
}

//DEL: Delete the entire linked list and set head to nullptr.
void delete_entire_linked_list(Node*& head) {
    if (head) {
        delete head;
        head = nullptr;
    }
}

//GET: Return the data of the node at the given index (0-indexed).
int get_linked_list_data_item_value(Node* head, int node_number) {
    Node* current = head;
    int index = 0;
    while (current) {
        if (index == node_number)
            return current->data;
        current = current->next;
        ++index;
    }
    throw std::out_of_range("Node number out of range");
}

//DELN: Delete the node at the specified index (0-indexed).
void delete_list_element(Node*& head, int node_number) {
    if (!head)
        return;
    
    if (node_number == 0) {
        Node* temp = head;
        head = head->next;
        temp->next = nullptr; // Prevent recursive deletion.
        delete temp;
        return;
    }
    
    Node* current = head;
    for (int i = 0; current && i < node_number - 1; i++) {
        current = current->next;
    }
    
    if (!current || !current->next)
        throw std::out_of_range("Node number out of range");
    
    Node* temp = current->next;
    current->next = temp->next;
    temp->next = nullptr;
    delete temp;
}
