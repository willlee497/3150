#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include <iostream>
#include <vector>
#include <stdexcept>

//N: Node Structure definition.
struct Node {
    int data;
    Node* next;

    //C: Constructor that initializes the node with a given value.
    Node(int val) : data(val), next(nullptr) {}

    //CC: Copy Constructor performing a deep copy of the list.
    Node(const Node& other);

    //D: Destructor that recursively deletes subsequent nodes.
    ~Node();
};

//BL: Build a linked list from a vector of integers.
Node* build_linked_list(const std::vector<int>& values);

//PL: Print the linked list in the format "value -> value -> ... -> nullptr".
void print_linked_list(Node* head);

//DEL: Delete the entire linked list and set the head pointer to nullptr.
void delete_entire_linked_list(Node*& head);

//GET: Retrieve the data from the node at the specified index (0-indexed).
int get_linked_list_data_item_value(Node* head, int node_number);

//DELN: Delete the node at the specified index (0-indexed).
void delete_list_element(Node*& head, int node_number);

#endif
